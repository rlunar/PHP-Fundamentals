<?php

$config = array(
	'DB_HOST'	  => 'localhost:/tmp/mysql.sock',
	'DB_USERNAME' => 'root',
	'DB_PASSWORD' => 'tutsplus'
);