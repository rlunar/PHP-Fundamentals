<?php
require 'classes/html.php';
?>
<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>

	<?= HTML::anchor('about/index.php', 'About Us'); ?>
	<?= HTML::image('http://d2o0t5hpnwv4c1.cloudfront.net/2100_node/preview.png', 'Node.js'); ?>

</body>
</html>