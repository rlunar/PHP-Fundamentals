<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Super Globals</h1>
	<?php echo htmlspecialchars($_GET['name']); ?>
</body>
</html>