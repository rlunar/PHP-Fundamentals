
<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Super Globals</h1>
	<?php 

	// if( isset($_GET['id']) ) {
	// 	echo htmlspecialchars($_GET['id']);
	// } else {
	// 	echo 'Redirect somewhere';
	// }

	?>

	<a href="about.php?name=joe">About</a>
</body>
</html>