<?php

/*
printf
sprintf
sscanf
*/

// printf("This post was made on %s %s, %d", 'June', '7th', '2012');


//$posted = sprintf("This post was made on %s %s, %d", 'June', '7th', '2012');
//echo $posted;


//list($month, $day, $year) = sscanf("June 7th, 2012", "%s %[^,], %d");
//sscanf("June 7th, 2012", "%s %[^,], %d", $month, $day, $year);
//echo $year;



