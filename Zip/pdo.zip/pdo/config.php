<?php

$config = array(
	'DB_USERNAME' => 'root',
	'DB_PASSWORD' => 'tutsplus'
);