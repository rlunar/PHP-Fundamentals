<?php

// Just for now...
define('USERNAME', 'JeffreyWay');
define('PASSWORD', '1234');
