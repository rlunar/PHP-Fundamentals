<?php

$arr = array('Jeff', 'Collis', 'Tash', 'Amanda');
// $arr = array(
// 	'ceo' => 'Collis',
// 	'manager' => 'Tash',
// 	'instructor' => 'Jeff'
// );

// foreach($arr as $title => $name) {
// 	echo "<li><strong>$title</strong> - $name</li>";
// }

// for( $i = 0; $i < count($arr); $i++ ) {
// 	echo "<li>$arr[$i]</li>";
// }

// $i = 0;
// while($i < count($arr) ) {
// 	echo "<li>$arr[$i]</li>";
// 	$i++;
// }
