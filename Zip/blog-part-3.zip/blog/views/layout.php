<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php include($view_path); ?>

</body>
</html>