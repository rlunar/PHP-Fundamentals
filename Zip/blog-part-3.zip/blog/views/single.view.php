<h2><?= $post['title']; ?></h2>
<div class="body"><?= $post['body']; ?></div>

<p><a href="/">Back</a></p>