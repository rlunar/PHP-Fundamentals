<!doctype html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>The Justin Bieber Fan Website</h1>
	<p>Visitor Count: <?php echo $count; ?></p>
</body>
</html>