<?php

require 'file.php';

File::truncate('sample.txt');